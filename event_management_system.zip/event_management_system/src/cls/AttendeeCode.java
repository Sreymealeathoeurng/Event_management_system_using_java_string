package cls;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttendeeCode {
    private static final String PREFIX = "STU";
    private static final int NB_DIGITS = 6;

    private static String formatNumber(int number) {
        return String.format("%0" + NB_DIGITS + "d", number);
    }

    private static String getLatestAttendeeId() {
        String id = null;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pstmt = con.prepareStatement("SELECT id FROM ATTENDEE ORDER BY id DESC LIMIT 1");
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                id = rs.getString("id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return id;
    }

    public static String generateAttendeeCode() {
        String newNumberPart = "";
        try {
            String latestId = getLatestAttendeeId();
            if (latestId != null) {
                // Remove prefix from the latest ID to get the number part
                String numberPart = latestId.substring(PREFIX.length());
                int numberValue = Integer.parseInt(numberPart);
                numberValue++;
                newNumberPart = formatNumber(numberValue);
            } else {
                newNumberPart = formatNumber(1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return PREFIX.concat(newNumberPart);
    }
}
