package cls;

public class KeyValue {
    private final int Key;
    private final String value;
    public KeyValue(int Key, String value){
        this.Key = Key;
        this.value = value;
    }
    public int getKey() {
        return Key;
    }
    public String getValue(){
        return value;
    }
    public String toString(){
        return value;
    }

}
