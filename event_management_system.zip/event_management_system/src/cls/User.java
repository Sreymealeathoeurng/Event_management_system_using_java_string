package cls;

public class User {
    private int id;              // ID of the user
    private static String userName;     // Username of the user
    private String password;     // Password of the user (note: usually, you'd not store passwords directly)
    private int roleId;          // Role ID of the user

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }
}
