package cls;

import cls.User;


public class AuthenticationState {
    private static boolean isAuthenticated = false;
    private static User user;

    public static boolean isAuthenticated() {
        return isAuthenticated;
    }

    public static void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public static User getUser() {
        return user;
    }

    public static void setUser(User user) {
        AuthenticationState.user = user;
    }
}
