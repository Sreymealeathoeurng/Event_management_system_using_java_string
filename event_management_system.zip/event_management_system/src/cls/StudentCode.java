package cls;

import db.DBConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentCode {
    private static final String prefix = "STU";
    private static final int nbDigit = 6;

    private static String formatNumber(int number) {
        String formatString = "%06d";
        return String.format(formatString, number);
    }

    private static String getStudentCode() {
        Connection con = null;
        String code = null;

        try {
            con = DBConnection.getConnection();
            String query = "SELECT code FROM event ORDER BY id DESC LIMIT 1";
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                code = resultSet.getString("code");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return code;
    }

    public static String generateStudentCode() {
        String newNumberPart = "";

        try {
            String oldCode = getStudentCode();
            if (oldCode != null) {
                String numberPart = oldCode.substring(prefix.length());
                int numberValue = Integer.parseInt(numberPart);
                numberValue++;
                newNumberPart = formatNumber(numberValue);
            } else {
                newNumberPart = formatNumber(1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return prefix.concat(newNumberPart);
    }
}
