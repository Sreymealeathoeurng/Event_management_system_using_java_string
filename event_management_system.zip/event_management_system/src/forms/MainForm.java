package forms;

import cls.KeyValue;
import db.DBConnection;
import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.DatePickerSettings;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.time.LocalDate;
import java.util.UUID;

public class MainForm extends JFrame {
    private JPanel MainPanel;
    private JButton btnAdd, btnUpdate, btnDelete, btnReset;
    private JPanel RightPanel, LeftPanel, dataPanel, tblPanel, datePickerPanel, AttendeePanel, PartnerPanel, btnPanel;
    private JLabel lblTitle, lblIcon;
    private JTextField txtId, txtTitle, txtLocation, txtUser_id;
    private JTextArea textAreaDes;
    private JComboBox<KeyValue> comboBoxAgenda, comboBoxOrganizer;
    private JTable EventTable;
    private JLabel lblN0;
    private JComboBox<KeyValue> cbostatus;
    private forms.DatePicker datePicker;

    private final KeyValue[] agendaItems = {
            new KeyValue(0, ""),
            new KeyValue(1, "Full day"),
            new KeyValue(2, "Half day (Morning)"),
            new KeyValue(3, "Half day (Evening)")
    };

    private final KeyValue[] organizerItems = {
            new KeyValue(0, ""),
            new KeyValue(1, "Team A"),
            new KeyValue(2, "Team B"),
            new KeyValue(3, "Team C")
    };

    private final KeyValue[] statusItems = {
            new KeyValue(0, ""),
            new KeyValue(1, "Approve"),
            new KeyValue(2, "Reject")
    };

    public MainForm() {
        setTitle("Create Event Dashboard");
        setContentPane(MainPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setLocationRelativeTo(null);
        getRootPane().setDefaultButton(btnAdd);

        initializeComponents();
        initializeListeners();
        loadEvents();
    }

    private void initializeComponents() {
        initializeComboBox();
        initializeDatePicker();
        initializeTable();
        setUpAttendeePanel();
        setUpPartnerPanel();
        setUpIconLabel();
    }

    private void initializeDatePicker() {
        DatePickerSettings dateSettings = new DatePickerSettings();
        dateSettings.setFormatForDatesCommonEra("yyyy-MM-dd");
        datePicker = new DatePicker(dateSettings);
        datePickerPanel.setLayout(new BorderLayout());
        datePickerPanel.add(datePicker, BorderLayout.CENTER);
    }

    private void initializeTable() {
        EventTable = new JTable(new DefaultTableModel(
                new Object[]{"ID", "Title", "Location", "Description", "Agenda", "Organizer", "Date", "User ID", "Status"}, 0
        ));
        EventTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        EventTable.setRowHeight(40);
        JScrollPane scrollPane = new JScrollPane(EventTable);
        LeftPanel.setLayout(new BorderLayout());
        LeftPanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void initializeComboBox() {
        for (KeyValue kw : agendaItems) {
            comboBoxAgenda.addItem(kw);
        }
        for (KeyValue kw : organizerItems) {
            comboBoxOrganizer.addItem(kw);
        }
        for (KeyValue kw : statusItems) {
            cbostatus.addItem(kw);
        }
    }

    private void initializeListeners() {
        btnAdd.addActionListener(e -> addEvent());
        btnUpdate.addActionListener(e -> updateEvent());
        btnDelete.addActionListener(e -> deleteEvent());
        btnReset.addActionListener(e -> clearControls());

        EventTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = EventTable.getSelectedRow();
                if (selectedRow != -1) {
                    String selectedEventId = (String) EventTable.getValueAt(selectedRow, 0);
                    loadEventById(selectedEventId);
                }
            }
        });

        MainPanel.registerKeyboardAction(e -> onCancel(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void setUpAttendeePanel() {
        AttendeePanel.setBackground(Color.CYAN);
        AttendeePanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        AttendeePanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openAttendeeForm();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                AttendeePanel.setBackground(Color.LIGHT_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                AttendeePanel.setBackground(Color.CYAN);
            }
        });
    }

    private void setUpPartnerPanel() {
        PartnerPanel.setBackground(Color.CYAN);
        PartnerPanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        PartnerPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    openPartnerForm();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                PartnerPanel.setBackground(Color.LIGHT_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PartnerPanel.setBackground(Color.CYAN);
            }
        });
    }

    private void setUpIconLabel() {
        lblIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new LoginForm(null).setVisible(true);
                dispose();
            }
        });
    }

    private void loadEvents() {
        DefaultTableModel tableModel = (DefaultTableModel) EventTable.getModel();
        tableModel.setRowCount(0);
        String query = "SELECT e.id, e.event_name, e.event_location, e.event_description, e.event_date, e.agenda_id, e.organizer_id, e.user_id, e.status_id FROM event e";

        try (Connection con = DBConnection.getConnection();
             Statement statement = con.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                addRowToTable(tableModel, resultSet);
            }
        } catch (SQLException ex) {
            showError("Error loading data from database: " + ex.getMessage());
        }
    }

    private void addRowToTable(DefaultTableModel tableModel, ResultSet resultSet) throws SQLException {
        String id = resultSet.getString("id");
        String eventName = resultSet.getString("event_name");
        String eventLocation = resultSet.getString("event_location");
        String eventDescription = resultSet.getString("event_description");
        LocalDate eventDate = resultSet.getDate("event_date").toLocalDate();
        int agendaId = resultSet.getInt("agenda_id");
        int organizerId = resultSet.getInt("organizer_id");
        String userId = resultSet.getString("user_id");
        int statusId = resultSet.getInt("status_id");

        tableModel.addRow(new Object[]{id, eventName, eventLocation, eventDescription, agendaId, organizerId, eventDate, userId, getStatusDescription(statusId)});
    }

    private String getStatusDescription(int statusId) {
        for (KeyValue status : statusItems) {
            if (status.getKey() == statusId) {
                return status.getValue();
            }
        }
        return "";
    }

    private void loadEventById(String id) {
        String query = "SELECT id, event_name, event_location, event_description, event_date, agenda_id, organizer_id, user_id, status_id FROM event WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                populateEventFields(rs);
            }
        } catch (SQLException ex) {
            showError("Error loading event: " + ex.getMessage());
        }
    }

    private void populateEventFields(ResultSet rs) throws SQLException {
        txtId.setText(rs.getString("id"));
        txtTitle.setText(rs.getString("event_name"));
        txtLocation.setText(rs.getString("event_location"));
        textAreaDes.setText(rs.getString("event_description"));
        txtUser_id.setText(rs.getString("user_id"));
        datePicker.setDate(rs.getDate("event_date").toLocalDate());
        setSelectedItemByKey(comboBoxAgenda, rs.getInt("agenda_id"));
        setSelectedItemByKey(comboBoxOrganizer, rs.getInt("organizer_id"));
        setSelectedItemByKey(cbostatus, rs.getInt("status_id"));
    }

    private void addEvent() {
        String id = txtId.getText();
        String eventName = txtTitle.getText();
        String eventLocation = txtLocation.getText();
        String eventDescription = textAreaDes.getText();
        String userId = txtUser_id.getText();
        LocalDate eventDate = datePicker.getDate();
        int agendaId = getKeyFromSelectedItem(comboBoxAgenda);
        int organizerId = getKeyFromSelectedItem(comboBoxOrganizer);
        int statusId = getKeyFromSelectedItem(cbostatus);

        if (validateEventInputs(id, eventName, eventLocation, eventDescription, userId, eventDate, statusId)) {
            if (!isValidStatusId(statusId)) {
                showError("Invalid status_id selected.");
                return;
            }

            try {
                int userIdInt = Integer.parseInt(userId);
                insertEvent(id, eventName, eventLocation, eventDescription, eventDate, agendaId, organizerId, userIdInt, statusId);
            } catch (NumberFormatException ex) {
                showError("User ID must be a valid number.");
            }
        }
    }

    private void insertEvent(String id, String eventName, String eventLocation, String eventDescription, LocalDate eventDate, int agendaId, int organizerId, int userId, int statusId) {
        String query = "INSERT INTO event (id, event_name, event_location, event_description, event_date, agenda_id, organizer_id, user_id, status_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, id);
            ps.setString(2, eventName);
            ps.setString(3, eventLocation);
            ps.setString(4, eventDescription);
            ps.setDate(5, Date.valueOf(eventDate));
            ps.setInt(6, agendaId);
            ps.setInt(7, organizerId);
            ps.setInt(8, userId);
            ps.setInt(9, statusId);

            ps.executeUpdate();
            loadEvents();
            clearControls();
        } catch (SQLException ex) {
            showError("Error inserting event: " + ex.getMessage() + ". Ensure status_id exists in the status table.");
        }
    }

    private void updateEvent() {
        int selectedRow = EventTable.getSelectedRow();
        if (selectedRow != -1) {
            String id = (String) EventTable.getValueAt(selectedRow, 0);
            String eventName = txtTitle.getText();
            String eventLocation = txtLocation.getText();
            String eventDescription = textAreaDes.getText();
            LocalDate eventDate = datePicker.getDate();
            int agendaId = getKeyFromSelectedItem(comboBoxAgenda);
            int organizerId = getKeyFromSelectedItem(comboBoxOrganizer);
            int statusId = getKeyFromSelectedItem(cbostatus);
            String userId = txtUser_id.getText();

            if (validateEventInputs(id, eventName, eventLocation, eventDescription, userId, eventDate, statusId)) {
                if (!isValidStatusId(statusId)) {
                    showError("Invalid status_id selected.");
                    return;
                }

                try {
                    int userIdInt = Integer.parseInt(userId);
                    updateEventInDb(id, eventName, eventLocation, eventDescription, agendaId, organizerId, eventDate, userIdInt, statusId);
                } catch (NumberFormatException ex) {
                    showError("User ID must be a valid number.");
                }
            }
        } else {
            showError("No event selected for update.");
        }
    }

    private void updateEventInDb(String id, String eventName, String eventLocation, String eventDescription, int agendaId, int organizerId, LocalDate eventDate, int userId, int statusId) {
        String query = "UPDATE event SET event_name = ?, event_location = ?, event_description = ?, agenda_id = ?, organizer_id = ?, event_date = ?, user_id = ?, status_id = ? WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, eventName);
            ps.setString(2, eventLocation);
            ps.setString(3, eventDescription);
            ps.setInt(4, agendaId);
            ps.setInt(5, organizerId);
            ps.setDate(6, Date.valueOf(eventDate));
            ps.setInt(7, userId);
            ps.setInt(8, statusId);
            ps.setString(9, id);

            ps.executeUpdate();
            loadEvents();
        } catch (SQLException ex) {
            showError("Error updating event: " + ex.getMessage());
        }
    }

    private void deleteEvent() {
        int selectedRow = EventTable.getSelectedRow();
        if (selectedRow != -1) {
            String id = (String) EventTable.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this event?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String query = "DELETE FROM event WHERE id = ?";

                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(query)) {

                    ps.setString(1, id);
                    ps.executeUpdate();
                    loadEvents();
                } catch (SQLException ex) {
                    showError("Error deleting event: " + ex.getMessage());
                }
            }
        } else {
            showError("No event selected for deletion.");
        }
    }

    private boolean validateEventInputs(String id, String eventName, String eventLocation, String eventDescription, String userId, LocalDate eventDate, int statusId) {
        if (id.isEmpty() || eventName.isEmpty() || eventLocation.isEmpty() || eventDescription.isEmpty() || userId.isEmpty() || eventDate == null || !isValidStatusId(statusId)) {
            showError("All fields are required and status_id must be valid.");
            return false;
        }
        return true;
    }

    private boolean isValidStatusId(int statusId) {
        for (KeyValue status : statusItems) {
            if (status.getKey() == statusId) {
                return true;
            }
        }
        return false;
    }

    private int getKeyFromSelectedItem(JComboBox<KeyValue> comboBox) {
        KeyValue selectedItem = (KeyValue) comboBox.getSelectedItem();
        return selectedItem != null ? selectedItem.getKey() : 0;
    }

    private void setSelectedItemByKey(JComboBox<KeyValue> comboBox, int key) {
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            KeyValue item = (KeyValue) comboBox.getItemAt(i);
            if (item.getKey() == key) {
                comboBox.setSelectedItem(item);
                break;
            }
        }
    }

    private void clearControls() {
        txtId.setText("");
        txtTitle.setText("");
        txtLocation.setText("");
        textAreaDes.setText("");
        txtUser_id.setText("");
        datePicker.clear();
        comboBoxAgenda.setSelectedIndex(0);
        comboBoxOrganizer.setSelectedIndex(0);
        cbostatus.setSelectedIndex(0);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void onCancel() {
        dispose();
    }

    private void openAttendeeForm() {
        new AttendeeForm().setVisible(true);
    }

    private void openPartnerForm() throws SQLException {
        new PartnerForm().setVisible(true);
    }
}
