package forms;

import cls.User;
import db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import static cls.AuthenticationState.setAuthenticated;

public class LoginForm extends JDialog {
    private JPanel MainPanel;
    private JTextField txtUserName;
    private JPasswordField txtPassword;
    private JLabel lblMsg; // Label for error messages
    private JButton btnLogin;
    private JButton btnCancel;
    private JLabel lblPassword;
    private JLabel lblUser;
    private JPanel LeftPanel;
    private JPanel RightPanel;
    private JLabel lblWelcome;
    private JLabel lblLoginForm;
    private JLabel lblTitle;
    private JLabel lblIcon;
    private JPanel FormPanel;

    public LoginForm(JFrame parent) {
        super(parent);
        setContentPane(MainPanel);
        setTitle("Login");
        setMinimumSize(new Dimension(600, 400));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        btnCancel.addActionListener(e -> dispose()); // Close the dialog
    }

    private void handleLogin() {
        String userName = txtUserName.getText().trim();
        String password = String.valueOf(txtPassword.getPassword()).trim();

        // Basic validation
        if (userName.isEmpty() || password.isEmpty()) {
            showMessage("Username and password must not be empty.");
            return;
        }

        String query = "SELECT * FROM user WHERE user_name = ? AND password = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement preparedStatement = con.prepareStatement(query)) {

            preparedStatement.setString(1, userName);
            preparedStatement.setString(2, password);

            try (ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserName(rs.getString("user_name"));
                    user.setRoleId(rs.getInt("role_id"));
                    setAuthenticated(true);

                    if (user.getRoleId() == 1) {
                        // User with role_id 1
                        MainForm mainForm = new MainForm();
                        mainForm.setVisible(true);
                    } else if (user.getRoleId() == 2) {
                        // User with role_id 2
                        AdminForm adminForm = new AdminForm();
                        adminForm.setVisible(true);
                    } else {
                        showMessage("Access denied for this role.");
                    }
                    dispose(); // Close the login form
                } else {
                    showMessage("Invalid username or password.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showMessage("Database error. Please try again later.");
        }
    }

    private void showMessage(String message) {
        lblMsg.setText(message);
        lblMsg.setForeground(Color.RED);
    }
}
