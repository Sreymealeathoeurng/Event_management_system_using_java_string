package forms;

import cls.KeyValue;
import cls.PartnerCode;
import db.DBConnection;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import static db.DBConnection.getConnection;

public class AttendeeForm extends JFrame {
    private JPanel MainPanel;
    private JPanel DataPanel;
    private JPanel TablePanel;
    private JLabel lblTitle;
    private JTextField txtN0;
    private JLabel lblN0;
    private JComboBox<KeyValue> comboType;
    private JButton btnAdd;
    private JButton btnDelete;
    private JTable tblAttendee;
    private JTextField txtName;
    private JTextField txtEvent;
    private JLabel lblIcon;
    private JLabel lbltitle;
    private JPanel dataPanel;
    private DefaultTableModel tableModel;

    private final KeyValue[] items = {
            new KeyValue(0, ""),
            new KeyValue(1, "Customer"),
            new KeyValue(2, "Partner"),
            new KeyValue(3, "Speaker")
    };

    public AttendeeForm() {
        setTitle("Attendee Management Dashboard");
        setContentPane(MainPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        initializeComponents();
        initializeListeners();
    }

    private void initializeComponents() {
        initializeTable();
        initializeComboBox();
        loadAttendeeData();
    }

    private void initializeTable() {
        tableModel = new DefaultTableModel(new Object[]{"N0", "Name", "Attendee Type", "Event ID"}, 0);
        tblAttendee.setModel(tableModel);
        tblAttendee.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblAttendee.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(tblAttendee);
        TablePanel.setLayout(new BorderLayout());
        TablePanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void initializeComboBox() {
        for (KeyValue kw : items) {
            comboType.addItem(kw);
        }
    }

    private void initializeListeners() {
        btnAdd.addActionListener(e -> addAttendee());
        btnDelete.addActionListener(e -> deleteSelectedAttendee());

        tblAttendee.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = tblAttendee.getSelectedRow();
                if (selectedRow != -1) {
                    String selectedId = tblAttendee.getValueAt(selectedRow, 0).toString();
                    loadAttendeeById(selectedId);
                }
            }
        });

        lblIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new MainForm().setVisible(true);
                dispose();
            }
        });
    }

    private void loadAttendeeData() {
        tableModel.setRowCount(0); // Clear existing data
        String query = "SELECT id, attendee_name, attendee_type_id, event_id FROM attendee";
        try (Connection con = getConnection();
             Statement statement = con.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                String id = resultSet.getString("id");
                String name = resultSet.getString("attendee_name");
                String typeId = resultSet.getString("attendee_type_id");
                String eventId = resultSet.getString("event_id");
                tableModel.addRow(new Object[]{id, name, typeId, eventId});
            }
        } catch (SQLException ex) {
            showError("Error loading data from database: " + ex.getMessage());
        }
    }

    private void loadAttendeeById(String id) {
        String query = "SELECT id, attendee_name, attendee_type_id, event_id FROM attendee WHERE id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, id);
            try (ResultSet resultSet = ps.executeQuery()) {
                if (resultSet.next()) {
                    txtN0.setText(resultSet.getString("id"));
                    txtN0.setEditable(false);
                    txtName.setText(resultSet.getString("attendee_name"));
                    txtEvent.setText(resultSet.getString("event_id"));
                    setSelectedItemByKey(comboType, resultSet.getInt("attendee_type_id"));
                }
            }
        } catch (SQLException ex) {
            showError("Error loading attendee data: " + ex.getMessage());
        }
    }

    private void addAttendee() {
        String id = txtN0.getText().isEmpty() ? PartnerCode.generatePartnerCode() : txtN0.getText();
        String name = txtName.getText();
        int typeId = getKeyFromSelectedItem(comboType);
        int eventId;

        try {
            eventId = Integer.parseInt(txtEvent.getText());
        } catch (NumberFormatException ex) {
            showError("Invalid event ID. Please enter a valid number.");
            return;
        }

        insertAttendee(id, name, typeId, eventId);
        clearControls();
        loadAttendeeData();
    }

    private void insertAttendee(String id, String name, int typeId, int eventId) {
        String sql = "INSERT INTO attendee (id, attendee_name, attendee_type_id, event_id) VALUES (?, ?, ?, ?)";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.setString(2, name);
            ps.setInt(3, typeId);
            ps.setInt(4, eventId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Attendee added successfully!");
        } catch (SQLException ex) {
            showError("Error inserting attendee: " + ex.getMessage());
        }
    }

    private void deleteSelectedAttendee() {
        int selectedRow = tblAttendee.getSelectedRow();
        if (selectedRow != -1) {
            String id = tblAttendee.getValueAt(selectedRow, 0).toString();
            deleteAttendee(id);
            clearControls();
            loadAttendeeData();
        } else {
            showError("No attendee selected.");
        }
    }

    private void deleteAttendee(String id) {
        String sql = "DELETE FROM attendee WHERE id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Attendee deleted successfully!");
        } catch (SQLException ex) {
            showError("Error deleting attendee: " + ex.getMessage());
        }
    }

    private void clearControls() {
        txtN0.setText("");
        txtName.setText("");
        txtEvent.setText("");
        comboType.setSelectedIndex(0);
        txtN0.setEditable(true); // Allow ID to be edited for new entries
    }

    private int getKeyFromSelectedItem(JComboBox<KeyValue> comboBox) {
        KeyValue selectedItem = (KeyValue) comboBox.getSelectedItem();
        return (selectedItem != null) ? selectedItem.getKey() : 0;
    }

    private void setSelectedItemByKey(JComboBox<KeyValue> comboBox, int key) {
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            KeyValue item = comboBox.getItemAt(i);
            if (item.getKey() == key) {
                comboBox.setSelectedItem(item);
                break;
            }
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
