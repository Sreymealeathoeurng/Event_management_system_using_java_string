package forms;

import cls.KeyValue;
import cls.PartnerCode;
import db.DBConnection;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

import static db.DBConnection.getConnection;

public class PartnerForm extends JFrame {
    private JPanel MainPanel;
    private JLabel lblPartner;
    private JLabel lblName;
    private JLabel lbldetail;
    private JPanel datapanel;
    private JPanel tblpanel;
    private JPanel Datepanel;
    private JTextField txtId;
    private JTextField txtname;
    private JComboBox<KeyValue> comboRole;
    private JTextArea textAreadetail;
    private JButton btnadd;
    private JButton btndlt;
    private JTable table1;
    private JLabel lblIcon;
    private DefaultTableModel tableModel;

    private final KeyValue[] items = {
            new KeyValue(0, ""),
            new KeyValue(1, "Sponsor"),
            new KeyValue(2, "Media Partner"),
            new KeyValue(3, "Volunteer")
    };

    public PartnerForm() throws SQLException {
        setTitle("Partner Information Form");
        setContentPane(MainPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        initializeTable();
        initializeComboBox();
        loadPartner();

        btnadd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = txtId.getText();

                if (id.isEmpty()) {
                    id = PartnerCode.generatePartnerCode(); // Assuming you have a method to generate a Partner code
                }

                String partner_name = txtname.getText();
                String partner_detail = textAreadetail.getText();
                int partner_role_id = getKeyFromSelectedItem(comboRole);

                insertPartner(id, partner_name, partner_role_id, partner_detail);
                clearControls(datapanel);
                loadPartner();
            }
        });

        btndlt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table1.getSelectedRow();

                if (selectedRow != -1) {
                    String id = txtId.getText();
                    deletePartner(id);
                    clearControls(datapanel);
                    loadPartner();
                } else {
                    JOptionPane.showMessageDialog(PartnerForm.this, "Please select a partner to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table1.getSelectedRow();
                    if (selectedRow != -1) {
                        String selectedId = table1.getValueAt(selectedRow, 0).toString();
                        loadPartnerById(selectedId);
                    }
                }
            }
        });
        lblIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new MainForm().setVisible(true); // Assuming MainForm has a no-argument constructor
                dispose();
            }
        });
    }

    private void initializeComboBox() {
        for (KeyValue kw : items) {
            comboRole.addItem(kw);
        }
    }

    private void initializeTable() {
        tableModel = new DefaultTableModel(new Object[]{"ID", "Partner Name", "Partner Role", "Partner Detail"}, 0);
        table1.setModel(tableModel);
        table1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table1.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(table1);
        scrollPane.setPreferredSize(new Dimension(900, 400));  // Set desired width and height

        tblpanel.setLayout(new BorderLayout());
        tblpanel.add(scrollPane, BorderLayout.CENTER);
    }

    private static void setSelectedItemByKey(JComboBox<KeyValue> comboBox, int key) {
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            KeyValue item = comboBox.getItemAt(i);
            if (item.getKey() == key) {
                comboBox.setSelectedItem(item);
                break;
            }
        }
    }

    private int getKeyFromSelectedItem(JComboBox<KeyValue> comboBox) {
        KeyValue selectedItem = (KeyValue) comboBox.getSelectedItem();
        return (selectedItem != null) ? selectedItem.getKey() : 0;
    }

    private void clearControls(Container container) {
        txtId.setText("");
        txtname.setText("");
        textAreadetail.setText("");
        for (Component component : container.getComponents()) {
            if (component instanceof JTextField) {
                ((JTextField) component).setText("");
            } else if (component instanceof JComboBox) {
                setSelectedItemByKey((JComboBox<KeyValue>) component, 0);
            }
        }
    }

    private void loadPartner() {
        tableModel.setRowCount(0);

        try (Connection con = getConnection();
             Statement statement = con.createStatement()) {
            String query = "SELECT partner.id, partner.partner_name, partner.partner_role_id, partner.partner_detail " +
                    "FROM partner " +
                    "INNER JOIN partner_role ON partner.partner_role_id = partner_role.id";

            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String id = resultSet.getString("id");
                String partner_name = resultSet.getString("partner_name");
                String partner_role_id = resultSet.getString("partner_role_id");
                String partner_detail = resultSet.getString("partner_detail");
                tableModel.addRow(new Object[]{id, partner_name, partner_role_id, partner_detail});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading data from database: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadPartnerById(String id) {
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(
                     "SELECT partner.id, partner.partner_name, partner.partner_role_id, partner.partner_detail " +
                             "FROM partner " +
                             "WHERE partner.id = ?")) {

            // Set the parameter for the query
            stmt.setString(1, id);

            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                txtId.setText(resultSet.getString("id"));
                txtId.setEditable(false);
                txtname.setText(resultSet.getString("partner_name"));
                textAreadetail.setText(resultSet.getString("partner_detail"));
                setSelectedItemByKey(comboRole, resultSet.getInt("partner_role_id"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data from database: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void insertPartner(String id, String partner_name, int partner_role_id, String partner_detail) {
        String insertSQL = "INSERT INTO partner(id, partner_name, partner_role_id, partner_detail) VALUES(?, ?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(insertSQL)) {

            stmt.setString(1, id);
            stmt.setString(2, partner_name);
            stmt.setInt(3, partner_role_id);
            stmt.setString(4, partner_detail);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Record inserted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to insert the record.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error inserting record: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePartner(String id) {
        String deleteSQL = "DELETE FROM partner WHERE id = ?";

        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(deleteSQL)) {

            stmt.setString(1, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Record deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete the record.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting record: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
