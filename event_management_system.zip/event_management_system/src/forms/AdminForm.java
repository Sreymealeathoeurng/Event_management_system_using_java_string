package forms;

import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class AdminForm extends JDialog {
    private JPanel MainPanel;
    private JButton btnApprove;
    private JButton btnReject;
    private JButton btnVD;
    private JTable EventTable;
    private JPanel LeftPanel;
    private JPanel btnPanel;
    private DefaultTableModel tableModel;

    public AdminForm() {
        setContentPane(MainPanel);
        setModal(true);
        getRootPane().setDefaultButton(btnApprove);
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setLocationRelativeTo(null);

        // Initialize components
        initializeTable();
        loadEvents(); // Load data immediately after initializing the table

        // Button listeners
        btnApprove.addActionListener(e -> ApproveEvent());
        btnReject.addActionListener(e -> RejectEvent());
        btnVD.addActionListener(e -> viewDetails());

        // Call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // Call onCancel() on ESCAPE
        MainPanel.registerKeyboardAction(e -> onCancel(), KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void initializeTable() {
        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Title", "Organizer", "User ID", "Status"}, 0
        );
        EventTable = new JTable(tableModel);
        EventTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        EventTable.setRowHeight(40);
        JScrollPane scrollPane = new JScrollPane(EventTable);
        LeftPanel.setLayout(new BorderLayout());
        LeftPanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void loadEvents() {
        tableModel.setRowCount(0); // Clear existing rows
        String query = "SELECT e.id, e.event_name, e.user_id, e.status_id, o.organizer_name " +
                "FROM event e " +
                "JOIN organizer o ON e.organizer_id = o.id"; // Adjust this to match your database schema

        try (Connection con = DBConnection.getConnection();
             Statement statement = con.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                String id = resultSet.getString("id");
                String eventName = resultSet.getString("event_name");
                String userId = resultSet.getString("user_id");
                String status = getStatusLabel(resultSet.getInt("status_id"));
                String organizer = resultSet.getString("organizer_name");

                tableModel.addRow(new Object[]{id, eventName, organizer, userId, status});
            }
        } catch (SQLException ex) {
            showError("Error loading data from database: " + ex.getMessage());
        }
    }

    private String getStatusLabel(int statusId) {
        switch (statusId) {
            case 1: return "Approved";
            case 0: return "Rejected";
            default: return "Pending";
        }
    }

    private void ApproveEvent() {
        int selectedRow = EventTable.getSelectedRow();
        if (selectedRow == -1) {
            showError("Please select an event to approve.");
            return;
        }

        String eventId = (String) EventTable.getValueAt(selectedRow, 0);
        if (updateEventStatus(eventId, 1)) { // Assuming 1 is for Approved
            tableModel.setValueAt("Approved", selectedRow, 4); // Update the status column in the table
        } else {
            showError("Failed to update event status.");
        }
    }

    private void RejectEvent() {
        int selectedRow = EventTable.getSelectedRow();
        if (selectedRow == -1) {
            showError("Please select an event to reject.");
            return;
        }

        String eventId = (String) EventTable.getValueAt(selectedRow, 0);
        if (updateEventStatus(eventId, 0)) { // Assuming 0 is for Rejected
            tableModel.setValueAt("Rejected", selectedRow, 4); // Update the status column in the table
        } else {
            showError("Failed to update event status.");
        }
    }

    private boolean updateEventStatus(String eventId, int statusId) {
        String query = "UPDATE event SET status_id = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, statusId);
            statement.setString(2, eventId);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            showError("Error updating event status: " + e.getMessage());
            return false;
        }
    }

    private void viewDetails() {
        int selectedRow = EventTable.getSelectedRow();
        if (selectedRow == -1) {
            showError("Please select an event to view details.");
            return;
        }

        String eventId = (String) EventTable.getValueAt(selectedRow, 0);
        String details = fetchEventDetails(eventId);
        JOptionPane.showMessageDialog(this, details, "Event Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private String fetchEventDetails(String eventId) {
        String query = "SELECT e.event_name, e.event_location, e.event_description, e.event_date, e.agenda_id, e.organizer_id " +
                "FROM event e " +
                "WHERE e.id = ?";
        StringBuilder details = new StringBuilder();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, eventId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                details.append("Event Name: ").append(resultSet.getString("event_name")).append("\n")
                        .append("Location: ").append(resultSet.getString("event_location")).append("\n")
                        .append("Description: ").append(resultSet.getString("event_description")).append("\n")
                        .append("Date: ").append(resultSet.getDate("event_date")).append("\n")
                        .append("Agenda ID: ").append(resultSet.getInt("agenda_id")).append("\n")
                        .append("Organizer ID: ").append(resultSet.getInt("organizer_id"));
            } else {
                details.append("Event not found.");
            }
        } catch (SQLException e) {
            details.append("Error fetching event details: ").append(e.getMessage());
        }

        return details.toString();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void onCancel() {
        dispose();
    }

    public static void main(String[] args) {
        AdminForm dialog = new AdminForm();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
