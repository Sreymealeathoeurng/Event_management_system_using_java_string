import db.DBConnection;
import forms.LoginForm;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        // Use SwingUtilities.invokeLater to ensure GUI is created on the EDT
        SwingUtilities.invokeLater(Main::run);
    }

    private static void run() {
        // Try to establish a database connection
        try (Connection con = DBConnection.getConnection()) {
            if (con != null) {
                System.out.println("Connection is connected successfully");

                // Create and show the LoginForm
                LoginForm loginForm = new LoginForm(null);
                loginForm.setVisible(true);
            } else {
                System.out.println("Can't connect to database");
                // Optionally show a message dialog or handle this case
                JOptionPane.showMessageDialog(null, "Cannot connect to the database. Please check your connection.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
